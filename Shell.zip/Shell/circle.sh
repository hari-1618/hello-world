echo "enter radius of circles"
read r
area=$(echo "scale=2;3.14*($r*$r)" | bc)
d=$(echo "scale=2; 2*$r" | bc)
circumference=$(echo "scale=2;3.14*$d" | bc)
echo "area of circle is $area"
echo "circumference of circle is $circumference"
